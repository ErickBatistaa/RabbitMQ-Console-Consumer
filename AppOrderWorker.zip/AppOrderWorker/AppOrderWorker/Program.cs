﻿// See https://aka.ms/new-console-template for more information
using AppOrderWorker.Domain.Models;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

var factory = new ConnectionFactory() { HostName = "localhost" };
using (var connection = factory.CreateConnection())
using (var channel = connection.CreateModel())
{
    channel.QueueDeclare(queue: "TESTE",
                         durable: false,
                         exclusive: false,
                         autoDelete: false,
                         arguments: null);

    var consumer = new EventingBasicConsumer(channel);
    consumer.Received += (model, ea) =>
    {
        try
        {
            var body = ea.Body.ToArray();
            var message = Encoding.UTF8.GetString(body);
            var order = System.Text.Json.JsonSerializer.Deserialize<Order>(message);

            Console.WriteLine($"[x] Order Number {order?.OrderNumber} | {order?.ItemName} | {order?.Price:N2}");

            channel.BasicAck(ea.DeliveryTag, false);
        }
        catch (Exception)
        {
            channel.BasicNack(ea.DeliveryTag, false, true);
        }
    };
    channel.BasicConsume(queue: "TESTE",
                         autoAck: false,
                         consumer: consumer);

    Console.WriteLine(" Press [enter] to exit.");
    Console.ReadLine();
}
